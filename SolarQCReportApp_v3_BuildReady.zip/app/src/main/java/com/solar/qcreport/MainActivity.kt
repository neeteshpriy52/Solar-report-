
package com.solar.qcreport

import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.ExifInterface

import android.graphics.*
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.*
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.*

data class RowData(
    val no: String,
    val activity: String,
    val spec: String,
    var status: String = "Completed",
    var remarks: String = "",
    var photo1: Uri? = null,
    var photo2: Uri? = null,
    var completion: String = ""
)

class SignatureView(context: Context) : View(context) {
    private val path = Path()
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.BLACK
        strokeWidth = 5f
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    override fun onDraw(c: Canvas) { super.onDraw(c); c.drawPath(path, paint) }
    override fun onTouchEvent(e: android.view.MotionEvent): Boolean {
        when(e.action) {
            MotionEvent.ACTION_DOWN -> { path.moveTo(e.x, e.y); invalidate(); return true }
            MotionEvent.ACTION_MOVE -> { path.lineTo(e.x, e.y); invalidate(); return true }
        }
        return true
    }
    fun bitmap(): Bitmap {
        val b = Bitmap.createBitmap(width.coerceAtLeast(1), height.coerceAtLeast(1), Bitmap.Config.ARGB_8888)
        val c = Canvas(b); c.drawColor(Color.WHITE); c.drawPath(path, paint); return b
    }
}

class MainActivity : AppCompatActivity() {
    private lateinit var root: LinearLayout
    private val rows = mutableListOf<RowData>()
    private val photoTargets = mutableMapOf<Int, Int>()
    private val photoViews = mutableMapOf<String, ImageView>()
    private val signatures = mutableListOf<SignatureView>()
    private var pendingPhoto: Pair<Int, Int>? = null
    private var cameraFile: File? = null

    private val takePhoto = registerForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        val p = pendingPhoto ?: return@registerForActivityResult
        val file = cameraFile
        if (ok && file != null && file.exists()) {
            val uri = Uri.fromFile(file)
            val row = rows[p.first]
            if (p.second == 1) row.photo1 = uri else row.photo2 = uri
            photoViews["${p.first}-${p.second}"]?.setImageURI(uri)
            addTimestampToImage(file)
        }
        pendingPhoto = null
        cameraFile = null
    }

    private val pickImage = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        val p = pendingPhoto ?: return@registerForActivityResult
        if (uri != null) {
            val row = rows[p.first]
            if (p.second == 1) row.photo1 = uri else row.photo2 = uri
            photoViews["${p.first}-${p.second}"]?.setImageURI(uri)
        }
        pendingPhoto = null
    }

    
    private val cameraPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) launchCamera()
        else Toast.makeText(this, "Camera permission required", Toast.LENGTH_SHORT).show()
    }

    private fun launchCamera() {
        val dir = File(getExternalFilesDir(null), "photos")
        dir.mkdirs()
        cameraFile = File(dir, "QC_${System.currentTimeMillis()}.jpg")
        val uri = FileProvider.getUriForFile(this, "${packageName}.fileprovider", cameraFile!!)
        takePhoto.launch(uri)
    }

    private fun addTimestampToImage(file: File) {
        try {
            val bmp = BitmapFactory.decodeFile(file.absolutePath) ?: return
            val mutable = bmp.copy(Bitmap.Config.ARGB_8888, true)
            val canvas = Canvas(mutable)
            val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.WHITE
                textSize = (mutable.width * 0.035f).coerceAtLeast(28f)
                typeface = Typeface.DEFAULT_BOLD
                setShadowLayer(5f, 2f, 2f, Color.BLACK)
            }
            val stamp = SimpleDateFormat("dd-MM-yyyy HH:mm:ss", Locale.getDefault()).format(Date())
            canvas.drawText("Date/Time: $stamp", 24f, mutable.height - 28f, paint)
            FileOutputStream(file).use { mutable.compress(Bitmap.CompressFormat.JPEG, 92, it) }
            bmp.recycle()
            mutable.recycle()
        } catch (_: Exception) {}
    }

override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        title = "Solar QC Report"
        buildUi()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun tv(text: String, size: Float = 16f, bold: Boolean = false): TextView =
        TextView(this).apply {
            this.text = text; textSize = size
            if (bold) setTypeface(typeface, Typeface.BOLD)
            setPadding(dp(8), dp(6), dp(8), dp(6))
        }

    private fun edit(hint: String, value: String = "") = EditText(this).apply {
        this.hint = hint; setText(value); textSize = 15f
        setPadding(dp(10), dp(8), dp(10), dp(8))
    }

    private fun buildUi() {
        val scroll = ScrollView(this)
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(12), dp(12), dp(28))
        }
        scroll.addView(root)
        setContentView(scroll)

        val logo = ImageView(this).apply {
            setImageResource(com.solar.qcreport.R.drawable.logo)
            adjustViewBounds = true
            scaleType = ImageView.ScaleType.CENTER_INSIDE
            layoutParams = LinearLayout.LayoutParams(-1, dp(100))
        }
        root.addView(logo)
        root.addView(tv("Inverter Installation Quality Control Report", 20f, true))
        root.addView(tv("GSE Renewables India Pvt Ltd • Mumbai", 14f))

        val project = edit("Project Name & Details")
        val owner = edit("Project Owner")
        val location = edit("Location")
        val client = edit("Client Name")
        val drawing = edit("Reference Document / Drawing")
        val start = edit("Date of Activity Start")
        val contractor = edit("I&C Contractor")
        val supervisor = edit("Site Supervisor / Engineer")
        val qc = edit("QC Engineer")
        listOf(project,owner,location,client,drawing,start,contractor,supervisor,qc).forEach { root.addView(it) }

        val specs = listOf(
            RowData("1.0","Marking","As per Approved Drawing/Inverter Standard"),
            RowData("2.0","Fabrication of Structure for Inverter Stand","As per Approved Drawing/Inverter Standard"),
            RowData("3.0","Installation of Structure / Stand / Bracket","Mounting surface level and structurally sound. Sequence - Bolt Head + Plain Washer + Inverter Stand + Plain Washer + Spring/Cut Washer + Nut. Torque as per drawing/manual."),
            RowData("","", "Marking should be done using permanent marker"),
            RowData("4.0","Installation of Inverter","Cable size as per BOM and approved make. Inverter mounted securely as per manufacturer specs."),
            RowData("5.0","Cable glanding / Inverter Gland","Type & size of gland must be approved by GSE. Gland tight; no gap between cable & gland."),
            RowData("6.0","Earthing of Inverter","Body earthing and potential/functional earthing as per approved standard."),
            RowData("7.0","Sealing of unused hole","Unused holes should be closed using silicon sealant"),
            RowData("8.0","Identification of Inverter","As per drawing; peel-off of sticker is not acceptable")
        )
        rows.addAll(specs)

        root.addView(tv("QC Checklist", 19f, true))
        rows.forEachIndexed { i, row -> addRowCard(i, row) }

        root.addView(tv("Final Signatures", 19f, true))
        repeat(3) { i ->
            root.addView(tv("Signature ${i+1}", 15f, true))
            val sig = SignatureView(this).apply {
                setBackgroundColor(Color.WHITE)
                layoutParams = LinearLayout.LayoutParams(-1, dp(120)).apply {
                    setMargins(0, dp(4), 0, dp(12))
                }
            }
            signatures.add(sig)
            root.addView(sig)
        }

        val gen = Button(this).apply {
            text = "GENERATE PDF REPORT"
            setOnClickListener {
                generatePdf(project.text.toString(), owner.text.toString(), location.text.toString(),
                    client.text.toString(), drawing.text.toString(), start.text.toString(),
                    contractor.text.toString(), supervisor.text.toString(), qc.text.toString())
            }
        }
        root.addView(gen)
    }

    private fun addRowCard(index: Int, row: RowData) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8),dp(8),dp(8),dp(12))
        }
        box.addView(tv("${row.no}  ${row.activity}", 16f, true))
        box.addView(tv(row.spec, 13f))
        val status = Spinner(this)
        status.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item,
            listOf("Completed","Pending","N/A"))
        status.setSelection(0)
        status.onItemSelectedListener = object: android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(p: android.widget.AdapterView<*>?) {}
            override fun onItemSelected(p: android.widget.AdapterView<*>?, v: View?, pos: Int, id: Long) {
                row.status = p?.getItemAtPosition(pos).toString()
            }
        }
        box.addView(status)
        val rem = edit("Observations / Remarks")
        box.addView(rem)
        rem.setOnFocusChangeListener { _, has -> if (!has) row.remarks = rem.text.toString() }
        val date = edit("Completion Date (DD-MM-YYYY)")
        box.addView(date)
        date.setOnFocusChangeListener { _, has -> if (!has) row.completion = date.text.toString() }

        val photoLine = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for (slot in 1..2) {
            val iv = ImageView(this).apply {
                setImageResource(android.R.drawable.ic_menu_camera)
                scaleType = ImageView.ScaleType.CENTER_CROP
                setBackgroundColor(Color.LTGRAY)
                layoutParams = LinearLayout.LayoutParams(0, dp(100), 1f).apply {
                    setMargins(dp(4),dp(4),dp(4),dp(4))
                }
                setOnClickListener {
                    pendingPhoto = index to slot
                    AlertDialog.Builder(this@MainActivity)
                        .setTitle("Add Photo")
                        .setItems(arrayOf("📷 Camera (Timestamp)", "🖼 Gallery / Existing Photo")) { _, which ->
                            if (which == 0) {
                                if (checkSelfPermission(android.Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                                    launchCamera()
                                } else {
                                    cameraPermission.launch(android.Manifest.permission.CAMERA)
                                }
                            } else {
                                pickImage.launch("image/*")
                            }
                        }.show()
                }
            }
            photoViews["$index-$slot"] = iv
            photoLine.addView(iv)
        }
        box.addView(photoLine)
        val line = View(this).apply { setBackgroundColor(Color.GRAY); layoutParams=LinearLayout.LayoutParams(-1,dp(1)) }
        root.addView(box); root.addView(line)
    }

    private fun readBitmap(uri: Uri): Bitmap? = try {
        contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
    } catch(_: Exception) { null }

    private fun drawWrapped(c: Canvas, text: String, x: Float, y0: Float, width: Float, paint: Paint, lineGap: Float = 14f): Float {
        var y=y0
        val words=text.replace("\r","").split(Regex("\\s+"))
        var line=""
        for (w in words) {
            val test=if(line.isEmpty()) w else "$line $w"
            if(paint.measureText(test)>width && line.isNotEmpty()) { c.drawText(line,x,y,paint); y+=lineGap; line=w }
            else line=test
        }
        if(line.isNotEmpty()){ c.drawText(line,x,y,paint); y+=lineGap }
        return y
    }

    private fun generatePdf(project:String, owner:String, location:String, client:String, drawing:String,
                            start:String, contractor:String, supervisor:String, qc:String) {
        rows.forEach { r ->
            // capture text even if fields are still focused
            val key = rows.indexOf(r)
            val card = root.getChildAt(10 + key*2) // best-effort; PDF uses current row state
        }
        val doc=PdfDocument()
        val pageW=595; val pageH=842
        var pageNum=1
        var page=doc.startPage(PdfDocument.PageInfo.Builder(pageW,pageH,pageNum).create())
        var c=page.canvas
        val p=Paint(Paint.ANTI_ALIAS_FLAG)
        p.color=Color.BLACK
        p.textSize=9f
        var y=30f
        val logoBmp=BitmapFactory.decodeResource(resources, R.drawable.logo)
        c.drawBitmap(logoBmp,null,RectF(30f,y,120f,y+52f),p)
        p.textSize=15f; p.typeface=Typeface.DEFAULT_BOLD
        c.drawText("Inverter Installation Quality Control Report",140f,y+20f,p)
        p.textSize=9f; p.typeface=Typeface.DEFAULT
        c.drawText("GSE Renewables India Pvt Ltd  •  Mumbai",140f,y+38f,p)
        y+=65
        fun line(label:String,value:String){ p.typeface=Typeface.DEFAULT_BOLD;c.drawText("$label:",30f,y,p);p.typeface=Typeface.DEFAULT;c.drawText(value,125f,y,p);y+=14 }
        line("Project",project); line("Owner",owner); line("Location",location); line("Client",client)
        line("Reference",drawing); line("Activity Start",start); line("I&C Contractor",contractor)
        line("Supervisor",supervisor); line("QC Engineer",qc)
        y+=5
        p.typeface=Typeface.DEFAULT_BOLD; p.textSize=8f
        val cols=floatArrayOf(25f,55f,135f,285f,365f,425f,505f,570f)
        val heads=arrayOf("Sr.","Activity","Specification / Parameter","Status","Remarks","Date","Photo")
        var rowH=34f
        fun newPageIfNeeded(h:Float) {
            if(y+h>810){
                doc.finishPage(page); pageNum++; page=doc.startPage(PdfDocument.PageInfo.Builder(pageW,pageH,pageNum).create()); c=page.canvas; y=30f
            }
        }
        // Header
        p.typeface=Typeface.DEFAULT_BOLD; p.textSize=7f
        c.drawText("Sr.",28f,y+10,p); c.drawText("Activity",58f,y+10,p); c.drawText("Specification / Parameter",137f,y+10,p)
        c.drawText("Status",367f,y+10,p); c.drawText("Remarks",426f,y+10,p); c.drawText("Date",506f,y+10,p)
        y+=18
        p.typeface=Typeface.DEFAULT; p.textSize=6.5f
        rows.forEach { r ->
            val maxH=58f
            newPageIfNeeded(maxH)
            val top=y
            val specEnd=drawWrapped(c,r.spec,137f,y+10,220f,p,9f)
            val remEnd=drawWrapped(c,r.remarks,426f,y+10,72f,p,8f)
            val actEnd=drawWrapped(c,r.activity,58f,y+10,75f,p,9f)
            val h=maxOf(28f,specEnd-y+6,remEnd-y+6,actEnd-y+6)
            p.typeface=Typeface.DEFAULT_BOLD;c.drawText(r.no,28f,y+10,p);p.typeface=Typeface.DEFAULT
            c.drawText(r.status,367f,y+10,p)
            c.drawText(r.completion.take(12),506f,y+10,p)
            val b1=readBitmap(r.photo1); val b2=readBitmap(r.photo2)
            if(b1!=null)c.drawBitmap(b1,null,RectF(500f,y+18,532f,y+45f),p)
            if(b2!=null)c.drawBitmap(b2,null,RectF(535f,y+18,567f,y+45f),p)
            p.style=Paint.Style.STROKE;c.drawRect(24f,top,570f,top+h,p);p.style=Paint.Style.FILL
            y+=h
        }
        newPageIfNeeded(160f)
        p.typeface=Typeface.DEFAULT_BOLD;p.textSize=8f
        c.drawText("GSE Project Manager",30f,y+14,p); c.drawText("GSE Quality Officer",220f,y+14,p); c.drawText("OE/Client Representative",410f,y+14,p)
        p.typeface=Typeface.DEFAULT;p.textSize=7f;c.drawText("Name / Sign & Date",30f,y+28,p);c.drawText("Name / Sign & Date",220f,y+28,p);c.drawText("Name / Sign & Date",410f,y+28,p)
        val sy=y+35
        signatures.forEachIndexed { i,s ->
            val left=30f+i*190f
            val bm=s.bitmap()
            c.drawBitmap(bm,null,RectF(left,sy,left+160f,sy+65f),p)
        }
        doc.finishPage(page)
        val dir=File(getExternalFilesDir(null),"reports");dir.mkdirs()
        val name="Solar_QC_${SimpleDateFormat("yyyyMMdd_HHmmss",Locale.US).format(Date())}.pdf"
        val out=File(dir,name)
        FileOutputStream(out).use{doc.writeTo(it)}
        doc.close()
        Toast.makeText(this,"PDF saved: ${out.name}",Toast.LENGTH_LONG).show()
        val pdfUri = FileProvider.getUriForFile(this, "${packageName}.fileprovider", out)
        val share=Intent(Intent.ACTION_SEND).apply{type="application/pdf";putExtra(Intent.EXTRA_STREAM,pdfUri);addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)}
        // Direct file sharing may be blocked on Android; use a simple open intent if needed.
        startActivity(Intent.createChooser(share, "Share PDF"))
    }
}
