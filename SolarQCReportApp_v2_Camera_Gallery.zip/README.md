
# Solar QC Report Android App

This is the first working MVP based on the uploaded **Inverter Installation Quality Control Report** Excel format.

Features:
- Camera + Gallery photo selection
- Camera photos get an automatic date/time watermark
- Project / owner / location / client fields
- QC checklist with Completed / Pending / N/A
- Remarks and completion date
- Two photos per checklist row
- Three signature boxes
- Embedded GSE logo from the supplied Excel
- PDF generation

## Phone-only build
Use AndroidIDE on Android, import this project folder, allow Gradle to sync, then Build > Assemble Debug. The APK will be generated under:
app/build/outputs/apk/debug/app-debug.apk

## Notes
This is a first version. The PDF renderer is intentionally kept native (PdfDocument) so it does not require a PDF library. The next iteration can match the Excel's exact merged-cell layout, fonts, borders and photo placement more closely.
